<!DOCTYPE html>
<html>
<body>

<p id="demo"></p>

<script>

document.getElementById("demo").innerHTML = "Hello World, this is Claire Munyole with HNGi7 ID HNG-00045 using JavaScript for stage 2 task";

</script>

</body>
</html>