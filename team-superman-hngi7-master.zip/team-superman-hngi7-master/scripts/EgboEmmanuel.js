function firstTask(fName, hId, lang) {
    console.log(
      `Nice Meeting you Here! This is ${fName} with HNGi7 ID of ${hId} using ${lang} for this stage task`
    );
  }
  firstTask("Egbo Emmanuel", "HNG-04843", "Javascript");
  