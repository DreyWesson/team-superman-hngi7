var info = function(fullname, id, language) {
    return `Hello World, this is ${fullname} with HNGi7-ID ${id} using ${language} for stage 2 task`
    
}
let newInfo = info("Emmanuel Udoh", "HNG-02600", "Javascript");
console.log(newInfo)