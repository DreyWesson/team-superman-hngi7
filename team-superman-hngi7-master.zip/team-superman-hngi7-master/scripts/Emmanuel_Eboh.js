
    const name = "Emmanuel Eboh";
    const id = "HNG-01574";
    const lang = "JavaScript";
    console.log(
        `Hello World, this is ${name} with ${id} using ${lang} for stage 2 task.`
        );
<<<<<<< HEAD:scripts/Emmanuel_Eboh.js
=======
</script>
</html>
>>>>>>> 61a28bfd62ddbaea8f710952e406e873c1f34f91:scripts/Emmanuel.Eboh.js
