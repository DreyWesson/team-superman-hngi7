let fullName = 'Ajayi John';
let ID = 'HNG-00374';
let language = 'javascript';

console.log(`Hello World, this is ${fullName} with HNG ID ${ID} using ${language} for stage 2 task`);
