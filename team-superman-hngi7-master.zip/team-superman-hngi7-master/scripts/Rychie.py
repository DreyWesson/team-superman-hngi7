print("Hello World, this is Richmond Ayitey with HNGi7 ID [HNG-00234] using Python language for HNGi7 task 2.")
