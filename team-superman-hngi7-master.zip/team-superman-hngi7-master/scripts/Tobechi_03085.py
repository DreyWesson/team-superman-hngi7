# -*- coding: utf-8 -*-
"""
Created on Wed Jun  3 01:48:52 2020

@author: Tobechi Chukwuleta
"""

import sys
def my_script():
    print('Hello World, this is %s with HNGi7 ID %s using %s language for stage 2 task.' % ('Chukwuleta Tobechi', 'HNG-03085', 'Python'))
    
my_script()
sys.stdout.flush()