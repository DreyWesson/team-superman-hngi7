const aaloleHngDetails = (name, id, lang) =>
  `Hello World.\n This is ${name},\n with HNGi7 ID ${id},\n using ${lang} for stage two task`;

console.log(aaloleHngDetails("Rasheed Mikail Abiodun", "HNG-02286", "JavaScript"));
