<?php
echo 'Hello World, this is Arturo Delgado with HNGi7 ID 00083 using PHP for stage 2 task';
