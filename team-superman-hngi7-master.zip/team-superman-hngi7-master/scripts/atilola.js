function davidAtilola(){

    let welcome = 'Hello World';
    let fullName = 'David Atilola';
    let iD = 'HNG-01583'
    let language = 'JavaScript';

    console.log (`${welcome}, this is ${fullName} with the HNGi7 ID ${iD} using ${language} for stage 2 task.`)
}
davidAtilola()
