var  FirstName= 'Olusola';
var SecondName= 'Adeyeye';
var FNDCode= 'HNG-04898';

console.log("Hello world this is " +  FirstName + " " + SecondName  +   " with " +  FNDCode); 