var name='Damilare Solanke';
var hngId='HNG-03896';
var language='javascript';

function myScript(fname,HngId,Language){
console.log(`Hello world, this is ${fname} with HNGi7 ID:${HngId} using ${Language} for stage 2 task`);
}
myScript(name,hngId,language);
