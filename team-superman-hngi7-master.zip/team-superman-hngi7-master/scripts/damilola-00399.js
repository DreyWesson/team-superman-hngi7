/*Stage 2 Task */

let fullName = "Damilola Owolabi"
let hngID = "HNG-00399"
let language = "JavaScript"

console.log(`Hello World, this is ${fullName} with HNGi7 ID: ${hngID} using ${language} for stage 2 task`)


