const internName = "Christian Ndu";
const hngId = "01290";
const preferredLang = "Javascript";

function namecheck(){
    console.log(`Hello world, this is ${internName} with HNGi7_ID ${0}${parseInt(hngId,10)} using ${preferredLang} for stage two task`)
}
//Number
namecheck()


