//Node.js 10.14.0
//Plain Javascript and Node.js is supported
// html/css is not supported here 

console.log("Hello World, this is Adibe Bamidele with HNGi7 ID HNG-04857 using JavaScript for stage 2 task")