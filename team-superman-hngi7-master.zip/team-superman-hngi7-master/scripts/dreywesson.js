function helloHng(fullname, id, language) {
  console.log(
    `Hello World, this is ${fullname} with HNGi7 ID ${id} using ${language} for stage 2 task`
  );
}
helloHng("Dare Oduwole", "HNG-00069", "Javascript");
