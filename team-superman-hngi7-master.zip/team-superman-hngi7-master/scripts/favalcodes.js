const fullName = "Favour Ezinne Arua";
const id = "HNG-04184";
let lang = "Javascript";

console.log(
    "Hello World, This is " + fullName + ", "+"with HNGi7 ID as " + id + " using "+ lang +" for stage 2 task."
    );
