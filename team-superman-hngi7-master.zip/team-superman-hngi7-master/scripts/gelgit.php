<!DOCTYPE html>
<html>
<body>

<?php
$hello = "Hello world this is Micheal Daralola Oketunde with HNGI7 ID: HNG-04388 using PHP for Stage 2 task";

echo json_encode($hello);
?>

</body>
</html>