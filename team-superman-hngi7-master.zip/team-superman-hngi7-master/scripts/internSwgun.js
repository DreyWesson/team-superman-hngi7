let fullName = "BANJI Olusegun Kolawole"
let hngID = "HNG-01595"
let language = "JavaScript"

console.log(`Hello World, this is ${fullName} with HNGi7 ID: ${hngID} using ${language} for stage 2 task`)
