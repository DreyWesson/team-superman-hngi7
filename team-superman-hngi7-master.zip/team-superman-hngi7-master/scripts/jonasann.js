function introduceSelf(){
    let fullName = "Ifeoma Oluwapelumi Jonah"
  let hngID = "HNG-04143"
  let language = "JavaScript"
  
  console.log(`Hello World, this is ${fullName} with HNGi7 ID: ${hngID} using ${language} for stage 2 task`)
  
  }
  introduceSelf();