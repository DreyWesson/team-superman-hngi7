const introduceYou = (fullName, id, language) => {
    console.log(`Hello World, this is ${fullName} with HNGi7 ID ${id} using ${language} for stage 2 task.`)
}

introduceYou('Oluwakayode Fadoju', 'HNG-01390', 'JavaScript')