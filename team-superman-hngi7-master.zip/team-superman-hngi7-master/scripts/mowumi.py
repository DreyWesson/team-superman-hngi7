def introduction(name, ID, language):
    print("Hello World, this is {} with HNGi7 ID {} using {} for stage 2 task.".format(name, ID, language))


introduction("Boluwatife Oduyemi", "HNG-00152", "Python")