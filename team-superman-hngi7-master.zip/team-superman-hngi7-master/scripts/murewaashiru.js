const introduction = (name, id, language) => {
  console.log(
    `Hello World, this is ${name} with HNGi7 ID ${id} using ${language} for stage 2 task.`
  );
};

introduction('Omomurewa George-Ashiru', 'HNG-00015', 'Node.js');
