def introduction(fullname, my_id, language):
    print("Hello World, this is {0} with HNGi7 ID {1} using {2} for stage 2 task" .format(fullname, my_id, language))

introduction("Olagesin Samuel", "HNG-04817", "Python")
