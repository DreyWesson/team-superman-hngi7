function sayHello(fullname, id, language) {
  console.log(
    `Hello World, this is ${fullname} with HNGi7 ${id} using ${language}`
  );
}
sayHello("yourname", "your_id", "your_lang");
