let fullName = "Muyiwa Adebayo"
let hngId = "HNG-03038"
let language = "JavaScript"

console.log(`Hello World, this is ${fullName} with HNGi7 ID: ${hngId} using ${language} for stage 2 task`)