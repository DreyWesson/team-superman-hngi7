const helloWorldHng = (fullName, id, language) => {
    console.log(`HelloWorld, This is ${fullName} with HNGi7 ID ${id} using ${language} for stage 2 task.`);
};

<<<<<<< HEAD:scripts/osaigbovo.js.js
helloWorldHng('Idiaghe osaigbovo', 'HNG-01879', 'JavaScript');
=======
helloWorldHng('Idiaghe osaigbovo', 'HNG-01879', 'JavaScript')
>>>>>>> e8d3557ccf32193fc7880bbc451c4c91643aaca8:scripts/osaigbovo.js
