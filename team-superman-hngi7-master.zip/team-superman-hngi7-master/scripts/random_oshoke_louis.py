
# A function to accept 3 string arguments and return an expected string 
# containing the HNGi7 Intern profile

def say_hello(full_name, id:int, language):
    return (f"Hello World, this is {full_name} with HNGi7 ID {id} using {language} for stage 2 task")


print(say_hello("Oshoke Louis", "HNG-01673", "python"))

