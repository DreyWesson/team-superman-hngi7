const greeting = "Hello World";

const fullName  = "Prince Chimaobi";

const hngId  = '00996';

const language = "JavaScript";


console.log(`${greeting}, This is ${fullName} with HNGi7 ID-${hngId} using ${language} for stage two task`);