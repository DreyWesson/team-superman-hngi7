<?php
$message = array("Silas Aigbemekhe","HNG-03916","PHP");
echo "Hello World, this is " . $message[0] ." ". "with HNG-ID " . $message[1] . " using " . $message[2] . " "."for stage 2 task";
?>