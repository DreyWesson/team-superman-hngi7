<?php
function task2($id, $fullname,$language ){
	
	return "Hello World, this is $fullname with HNGi7 ID $id using $language for stage 2 task";
//}
return true;
}

echo task2("HNG-03514", "Ebuka John Ede", "PHP");